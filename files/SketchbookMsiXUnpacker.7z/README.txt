===============================================
                                             
 _       ___ ___   ___       _   _         _ 
| |_ ___|   |_  | |_  |  ___| |_| |_   ___| |
|  _|  _| | |_| |_|  _|_| . |  _| '_|_|  _| |
|_| |___|___|_____|___|_|_  |_| |_,_|_|___|_|
                        |___|                

===============================================
I am not responsible for the actions that you 
chose to do.

How to use: 
Drag .msixbundle file into the batch file on Windows Explorer, it will then extract it for you and move it onto the desktop.

FAQ:
Will this work on newer versions?
Yes as it just extracts it

Will you add a ARM64 Native version?
In the future once I have the time

Does auto update work?
No. 

by tc012.gtk.cl